# Iwara Reverse Proxy（Node.js 零依赖反代）

用纯 Node.js（无需 `npm install`）实现的 [iwara.tv](https://www.iwara.tv) 整站反向代理，
同时支持 AI 站 [iwara.ai](https://www.iwara.ai)。
主页、视频播放、搜索、图片、登录、论坛均可直接使用，默认**全站去广告**。

## 快速开始

```bash
node proxy.js
# 打开 http://127.0.0.1:8888/        (iwara.tv 主站)

# AI 站（另开一个端口，可同时运行）：
PORT=8889 SITE_DOMAIN=iwara.ai node proxy.js
# 打开 http://127.0.0.1:8889/        (iwara.ai)
```

要求：Node.js ≥ 16，且本机能访问 iwara.tv / iwara.ai（或通过下述 `UPSTREAM_PROXY`）。
系统需有 `curl` 命令（Windows 10+ 自带，Git Bash 也自带）——默认传输层用它模拟浏览器 TLS/HTTP2 指纹。

## 工作原理

```
浏览器 ──HTTP──> 本代理 (proxy.js) ──curl/HTTPS──> *.iwara.tv
                  │
                  ├─ /              → www.iwara.tv   (SPA 页面 / _next 资源 / 字体)
                  ├─ /p/<host>/...  → 对应子域        (api. / i. / filesq. / 视频服务器…)
                  │
                  ├─ HTML/JS/CSS    → 相对路径重写 + 注入运行时补丁(hook fetch/XHR/URL)
                  ├─ JSON/API       → 重写为本站绝对 URL(前端会 new URL() 解析 fileUrl)
                  └─ 视频等二进制    → 流式透传(支持 Range 断点/206)
```

关键细节（都是实测踩出来的坑）：

- **Cloudflare 质询**：Node 原生 https 的 TLS 指纹会被 CF 质询（`cf-mitigated: challenge`），
  因此默认用系统 `curl` 做上游传输，并遵守其指纹规则：
  UA 必须用 `-A` 传入（`-H 'user-agent: ...'` 会改变请求头顺序立刻触发质询），
  且不显式发送 `accept` / `accept-encoding` 头（同样触发质询）。
  其余请求头按白名单转发（cookie / authorization / range / x-version / referer / origin 等）。
- **运行时补丁**：前端 JS 在运行时拼接 `"//" + "api.iwara.tv"` 这类地址，静态重写无法命中，
  所以向 HTML 注入补丁 hook `fetch` / `XMLHttpRequest` / `setAttribute` / 常用 `src|href` 属性 /
  `URL` 构造器，把漏网请求在运行时改写为 `/p/<host>/...`。
- **JSON 绝对地址**：播放器会用 `new URL(video.fileUrl)` 解析清单地址，相对路径会抛
  `Invalid URL`，因此 JSON 响应中的 URL 重写为 `http://<当前Host>/p/<host>/...` 绝对地址。
- **Service Worker**：Iwara 的 workbox 离线缓存 SW 会提供过期缓存、绕过补丁，代理直接把它
  替换为空操作脚本；HTML 强制 `no-cache`、JSON 强制 `no-store`（fileUrl 是带过期签名的）。

## 环境变量

| 变量 | 默认 | 说明 |
| --- | --- | --- |
| `PORT` | `8888` | 监听端口 |
| `SITE_DOMAIN` | `iwara.tv` | 站点域名家族；设为 `iwara.ai` 即为 AI 站实例（自动同时放行 `*.iwara.tv` 后端域） |
| `UPSTREAM_SITE` | `www.<SITE_DOMAIN>` | 默认回源站点 |
| `UPSTREAM_PROXY` | 空 | 本机无法直连 iwara 时走 HTTP(CONNECT) 代理，如 `http://127.0.0.1:7890`（clash/v2ray 的 http 端口），同时支持 `HTTPS_PROXY` 环境变量 |
| `TRANSPORT` | `curl` | 上游传输方式；`node` 为纯 Node https（会被 CF 质询，仅备用） |
| `EXTRA_HOSTS` | 空 | 额外允许反代的域名（逗号分隔），默认白名单为站点域名家族 |
| `BLOCK_HOSTS` | 空 | 追加拦截的域名（逗号分隔） |
| `NO_AD_BLOCK` | `0` | 设为 `1` 关闭广告拦截 |
| `ALLOW_ANY_HOST` | `0` | 设为 `1` 关闭白名单（会变成开放代理，不建议） |
| `DEBUG` | `0` | 设为 `1` 输出调试日志 |

### AI 站说明

iwara.ai 与主站**共用同一套前端 bundle 和 api/iwara.tv 后端**，仅靠请求头
`X-Site: www.iwara.ai` 区分内容（图片 i.iwara.tv、视频文件 *.iwara.tv 也是共用的）。
AI 实例会自动做两件事：

1. 同时放行/重写 `*.iwara.ai` 与 `*.iwara.tv` 两个域名家族；
2. 把浏览器发来的 `X-Site: 127.0.0.1`（本代理地址）改写为 `www.iwara.ai`，
   否则后端不认识该主机名，会一直返回主站内容。

两个实例可以同时运行（如 8888 主站 + 8889 AI 站），互不影响。

## 测试

```bash
node test.js    # URL 重写 / 路由解析 / 白名单 / 补丁语法 单元测试
```

## 已验证功能

- ✅ 主页（视频网格、论坛主题、公告、分页加载）
- ✅ 视频播放（播放器、画质菜单、进度缓冲、Range/206 流式转发）
- ✅ 搜索（`/search?type=videos&query=...`，各类别标签）
- ✅ 图片（头像、视频缩略图，`i.iwara.tv` 全部经代理）
- ✅ 登录（页面渲染 + `POST /p/api.iwara.tv/user/login` 全链路，错误凭据能收到
  API 的 "Invalid email or password." 响应；真实凭据即可登录）
- ✅ 论坛（分类、帖子列表、帖子内页）
- ✅ R-18 内容：登录后即可观看（该类视频匿名状态本来就不提供播放器）
- ✅ AI 站 iwara.ai（`SITE_DOMAIN=iwara.ai` 实例：AI 内容、视频流 lynx.iwara.tv、
  缩略图、论坛全部正常）
- ✅ 去广告（广告域 204 拦截 + contentBlock 容器隐藏，详见下文）
- ✅ 公告/评论里的 "Click to display" 图片遮罩自动展开（MutationObserver 自动点击）

## 去广告说明

| 层 | 手段 |
| --- | --- |
| 网络层 | 广告/追踪域名直接返回 204：`service.iwara.tv`（自有 Revive 广告服务器）、`service.iwara.shop`、`for-iwara-tools.tyamahori.com`、googletagmanager / google-analytics / doubleclick |
| 重写层 | 上述域名加入 URL 重写正则（静态 + 运行时补丁），确保浏览器请求都进入代理被拦截，而不是直连漏网 |
| 样式层 | 注入 CSS `.contentBlock{display:none!important}`，隐藏广告组件占位容器（`<Ad>` 组件渲染的 contentBlock），不留空白 |
| 图片遮罩 | 公告/评论/论坛帖中非白名单前缀图片默认要点击才显示，注入 MutationObserver 自动点击展开 |

## 已知限制

- **明文 HTTP**：代理本身是 HTTP，若部署到公网，请在前面加一层 TLS
  （nginx/caddy，或 `npx local-ssl-proxy --source 443 --target 8888`），
  代理已支持 `X-Forwarded-Proto`。本地/局域网使用则无此问题。
- **Cloudflare**：极端情况下（IP 信誉差）可能遇到人机验证页，换出口 IP
  （`UPSTREAM_PROXY`）即可；浏览器里手动过一次验证后 cookie 会透传保持。
- **上传**：普通 POST（登录、评论等）已验证可用；大文件上传未做专门优化。
- 仅供个人学习研究使用，请遵守目标网站的服务条款，不要用于公开镜像/分发。
