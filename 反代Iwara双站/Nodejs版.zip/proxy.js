#!/usr/bin/env node
/**
 * Iwara Reverse Proxy — 纯 Node.js 实现（零依赖）
 *
 * 路由规则：
 *   /                     -> https://www.iwara.tv/...        (主页 / 视频页 / 搜索 / 论坛 等 SPA 路由)
 *   /p/<host>/<path>      -> https://<host>/<path>           (api.iwara.tv / i.iwara.tv / 视频文件服务器 等)
 *
 * 工作方式：
 *   1. 回源请求 HTML / JS / JSON / CSS / RSC 文本，将其中的 iwara 域名 URL 重写为本站相对路径
 *      (覆盖明文、JSON 转义 \/、\u002F、百分号编码、协议相对 //host 等形式)
 *   2. HTML 中注入一段运行时补丁，hook fetch / XHR / setAttribute / 常用 src|href 属性 / URL 构造器，
 *      兜底处理 JS 运行期动态拼出来的绝对地址
 *   3. 视频等二进制流原样透传（支持 Range 断点），Cookie / 登录请求头透传
 *
 * 环境变量：
 *   PORT=8888                 监听端口
 *   UPSTREAM_SITE=www.iwara.tv  默认回源站点
 *   UPSTREAM_PROXY=http://127.0.0.1:7890  本机无法直连 iwara 时，走 HTTP(CONNECT) 代理出口
 *   EXTRA_HOSTS=a.com,b.com   额外允许反代的域名（默认白名单为 *.iwara.tv）
 *   ALLOW_ANY_HOST=1          关闭白名单（不推荐，会变成开放代理）
 *   DEBUG=1                   输出详细日志
 */
'use strict';

const http = require('http');
const https = require('https');
const tls = require('tls');
const zlib = require('zlib');
const { URL } = require('url');
const { spawn } = require('child_process');

/* ------------------------------ 配置 ------------------------------ */

const PORT = Number(process.env.PORT || 8888);
// 站点域名家族。Iwara 的 AI 站(www.iwara.ai)与主站共用同一套前端 bundle 和
// api/iwara.tv 后端，仅靠请求头 X-Site: www.iwara.ai 区分内容（图片/视频也共用
// i./files. *.iwara.tv），因此 AI 站实例需要同时放行/重写两个域名家族。
// 用法：PORT=8889 SITE_DOMAIN=iwara.ai node proxy.js
const SITE_DOMAINS = [...new Set([
  (process.env.SITE_DOMAIN || 'iwara.tv').trim().toLowerCase(),
  'iwara.tv', // 后端/图片/视频固定在 iwara.tv 家族
])];
const SITE_HOST = (process.env.UPSTREAM_SITE || ('www.' + SITE_DOMAINS[0])).toLowerCase();
const PREFIX = '/p/';
const DEBUG = process.env.DEBUG === '1';
const ALLOW_ANY_HOST = process.env.ALLOW_ANY_HOST === '1';
const EXTRA_HOSTS = (process.env.EXTRA_HOSTS || '')
  .split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
const UPSTREAM_PROXY = process.env.UPSTREAM_PROXY
  || process.env.HTTPS_PROXY || process.env.https_proxy
  || process.env.HTTP_PROXY || process.env.http_proxy || '';

/* ------------------------- 广告 / 追踪拦截 -------------------------
 * Iwara 的广告系统：
 *   - service.iwara.tv          自有广告服务器(Revive Adserver, /z/z.php 按 zone 下发广告 HTML)
 *   - service.iwara.shop        广告横幅脚本宿主(aa-server-select)
 *   - for-iwara-tools.tyamahori.com  外部广告横幅图
 * 页面容器由 <Ad> 组件渲染，容器类名为 contentBlock / contentBlock__content，
 * 广告 HTML 注入前容器只是空白占位，因此拦截请求 + CSS 隐藏容器即可完全去除广告。
 * 追踪类域名一并拦截。
 */
const AD_HOSTS = [
  'service.iwara.tv',
  'service.iwara.ai',
  'service.iwara.shop',
  'for-iwara-tools.tyamahori.com',
  'www.googletagmanager.com',
  'www.google-analytics.com',
  'analytics.google.com',
  'stats.g.doubleclick.net',
];
const USER_BLOCK_HOSTS = (process.env.BLOCK_HOSTS || '')
  .split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
const BLOCKED_HOSTS = new Set(AD_HOSTS.concat(USER_BLOCK_HOSTS).map((h) => h.replace(/:\d+$/, '')));
const NO_AD_BLOCK = process.env.NO_AD_BLOCK === '1';

// 这些域名需要加入 URL 重写正则（否则浏览器会绕过代理直连它们，拦截不生效）
const RE_AD_HOSTS = [
  'service\\.iwara\\.shop',
  'service\\.iwara\\.ai',
  'for-iwara-tools\\.tyamahori\\.com',
  'www\\.googletagmanager\\.com',
  'www\\.google-analytics\\.com',
  'analytics\\.google\\.com',
  'stats\\.g\\.doubleclick\\.net',
];
// 上游传输方式：curl(默认，模拟浏览器 TLS/HTTP2 指纹，绕过 Cloudflare 对 Node 指纹的拦截) | node
let TRANSPORT = (process.env.TRANSPORT || 'curl').toLowerCase();
let curlExtraArgs = [];

const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);
const dbg = (...a) => { if (DEBUG) console.log('[debug]', ...a); };

/* --------------------------- host 白名单 --------------------------- */

function isBlockedHost(host) {
  if (NO_AD_BLOCK) return false;
  host = String(host || '').toLowerCase().replace(/\.+$/, '').replace(/:\d+$/, '');
  return BLOCKED_HOSTS.has(host);
}

function isAllowedHost(host) {
  host = String(host || '').toLowerCase().replace(/\.+$/, '');
  if (!/^[a-z0-9.-]+$/.test(host)) return false;
  host = host.replace(/:\d+$/, '');
  if (!host) return false;
  if (isBlockedHost(host)) return true; // 黑名单域名也要能进代理，才能在代理层被拦截
  if (ALLOW_ANY_HOST) return true;
  if (SITE_DOMAINS.some((d) => host === d || host.endsWith('.' + d))) return true;
  return EXTRA_HOSTS.some((h) => host === h || host.endsWith('.' + h));
}

/* ---------------------------- URL 重写 ---------------------------- */

function escapeRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

// 站点本身(裸域/www) -> 同源；其余子域 -> /p/<host>
const BARE_HOSTS = new Set();
for (const d of SITE_DOMAINS) { BARE_HOSTS.add(d); BARE_HOSTS.add('www.' + d); }

const BASE_LABEL = '(?:[a-zA-Z0-9-]+\\.)*(?:' + SITE_DOMAINS.map(escapeRe).join('|') + ')';
const HOSTS_SRC = '(?:' + [BASE_LABEL].concat(RE_AD_HOSTS, EXTRA_HOSTS.map(escapeRe)).join('|') + ')';

// https://host   https:\/\/host   https\u003A\u002F\u002Fhost ...
const RE_ABS = new RegExp(
  'https(?::|\\\\u003[aA]|\\\\x3[aA])(?:\\/\\/|\\\\\\/\\\\\\/|\\\\u002[fF]\\\\u002[fF])'
  + '(' + HOSTS_SRC + ')(?::443)?(?![a-zA-Z0-9-])',
  'gi'
);
// https%3A%2F%2Fhost （出现在 query 参数等已编码场景）
const RE_PCT = new RegExp('https%3[aA]%2[fF]%2[fF](' + HOSTS_SRC + ')(?::443)?', 'gi');
// 协议相对 //host
const RE_REL = new RegExp('(?<![\\w.:-])\\/\\/(' + HOSTS_SRC + ')(?![a-zA-Z0-9-])', 'gi');

// origin 为空 -> 重写为相对路径(用于 HTML/JS/CSS)
// origin 非空(如 http://127.0.0.1:8888) -> 重写为本站绝对 URL(用于 JSON/API 响应,
// 因为前端会用 new URL(fileUrl) 解析 pathname/search,相对路径会抛 Invalid URL)
function makeRewriter(origin) {
  const abs = (h) => {
    h = h.toLowerCase().replace(/:443$/, '');
    if (BARE_HOSTS.has(h)) return origin || '';
    return origin ? origin + PREFIX + h : PREFIX + h;
  };
  return function rewriteText(text) {
    text = text.replace(RE_ABS, (m, h) => abs(h));
    text = text.replace(RE_PCT, (m, h) => {
      const r = abs(h);
      return r ? encodeURIComponent(r) : '';
    });
    text = text.replace(RE_REL, (m, h) => abs(h));
    return text;
  };
}

function rewriteText(text, origin) {
  return makeRewriter(origin || null)(text);
}

function requestOrigin(req) {
  const xf = String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim();
  return (xf || 'http') + '://' + (req.headers.host || '127.0.0.1');
}

/* ------------------------ 浏览器端运行时补丁 ------------------------ */

const CLIENT_HOST_SRC =
  '((?:[a-z0-9-]+\\.)*(?:' + SITE_DOMAINS.map(escapeRe).join('|') +
  (RE_AD_HOSTS.length || EXTRA_HOSTS.length
    ? '|' + RE_AD_HOSTS.concat(EXTRA_HOSTS.map(escapeRe)).join('|')
    : '') +
  '))';
const CLIENT_BARE = {};
for (const h of BARE_HOSTS) CLIENT_BARE[h] = 1;
const CLIENT_DOMAIN_ALT = SITE_DOMAINS.map(escapeRe).join('|');

const PATCH_JS = [
  '(function(){',
  '"use strict";',
  'window.__iwaraProxyErrors=[];',
  'window.addEventListener("error",function(e){window.__iwaraProxyErrors.push(String(e.message||e.error)+" @ "+String(e.filename||"").slice(-70)+":"+e.lineno);});',
  'window.addEventListener("unhandledrejection",function(e){window.__iwaraProxyErrors.push("REJ: "+String(e.reason).slice(0,150)+" STACK: "+String(e.reason&&e.reason.stack||"").slice(0,400));});',
  'var HS=' + JSON.stringify(CLIENT_HOST_SRC) + ';',
  'var BARE=' + JSON.stringify(CLIENT_BARE) + ';',
  'var DOMALT=' + JSON.stringify(CLIENT_DOMAIN_ALT) + ';',
  'var FAKE="http://iwara-proxy.invalid";',
  'var RX=new RegExp("^https?://"+HS+"(?=[/?#:]|$)","i");',
  'var RX3=new RegExp("^//"+HS+"(?=[/?#:]|$)","i");',
  'var RX2=/^http:\\/\\/iwara-proxy\\.invalid(?=[\\/?#:]|$)/;',
  'function fix(u){',
  ' try{',
  '  if(u&&typeof u==="object"&&typeof u.href==="string")u=u.href;',
  '  if(typeof u!=="string"||!u)return u;',
  '  if(u.charAt(0)==="/"&&u.charAt(1)==="/"){',
  '   var m3=RX3.exec(u);',
  '   if(m3){var h3=m3[1].toLowerCase(),r3=u.slice(m3[0].length);',
  '    if(BARE[h3])return r3||"/";',
  '    return "/p/"+h3+r3;}',
  '   return u;}',
  '  if(u.charAt(0)==="/"&&u.charAt(1)!=="/")return u;',
  '  if(RX2.test(u))return u.slice(FAKE.length)||"/";',
  '  var m=RX.exec(u);',
  '  if(!m)return u;',
  '  var h=m[1].toLowerCase(),rest=u.slice(m[0].length);',
  '  if(BARE[h])return rest||"/";',
  '  return "/p/"+h+rest;',
  ' }catch(e){return u;}',
  '}',
  'try{var of=window.fetch;if(of)window.fetch=function(input,init){try{',
  '  if(typeof input==="string")input=fix(input);',
  '  else if(input&&typeof input.href==="string")input=fix(input);',
  '}catch(e){}return of.call(this,input,init);};}catch(e){}',
  'try{var oo=XMLHttpRequest.prototype.open;XMLHttpRequest.prototype.open=function(){',
  '  var a=[].slice.call(arguments);if(typeof a[1]==="string")a[1]=fix(a[1]);',
  '  return oo.apply(this,a);};}catch(e){}',
  'try{var os=Element.prototype.setAttribute;Element.prototype.setAttribute=function(n,v){',
  '  if(typeof v==="string"&&/^(src|href|poster|action|data)$/i.test(n))v=fix(v);',
  '  return os.call(this,n,v);};}catch(e){}',
  '[["HTMLImageElement","src"],["HTMLSourceElement","src"],["HTMLIFrameElement","src"],',
  ' ["HTMLScriptElement","src"],["HTMLTrackElement","src"],["HTMLMediaElement","src"],',
  ' ["HTMLMediaElement","poster"],["HTMLAnchorElement","href"],["HTMLLinkElement","href"],',
  ' ["HTMLFormElement","action"]].forEach(function(p){try{',
  '  var C=window[p[0]];if(!C)return;',
  '  var d=Object.getOwnPropertyDescriptor(C.prototype,p[1]);',
  '  if(d&&d.set&&d.configurable)Object.defineProperty(C.prototype,p[1],{',
  '    configurable:true,enumerable:d.enumerable,get:d.get,',
  '    set:function(v){return d.set.call(this,fix(v));}});',
  ' }catch(e){}});',
  'try{window.URL=(function(PU){return class extends PU{constructor(u,b){try{',
  '  if(typeof b==="string"&&b.charAt(0)==="/"){',
  '    var m=new RegExp("^\\\\/p\\\\/((?:[a-z0-9-]+\\\\.)*(?:"+DOMALT+"))(?:\\\\/.*)?$","i").exec(b);',
  '    if(m){if(typeof u==="string"&&u.charAt(0)==="/")u=FAKE+u;b=FAKE+"/p/"+m[1]+"/";}',
  '  }',
  '}catch(e){}super(u,b);}};})(URL);}catch(e){}',
  // 自动展开 "Click to display" 图片遮罩(markdown 组件对非白名单前缀图片的占位按钮)。
  // 代理重写后 JSON 里的图片 src 是绝对地址而 bundle 白名单是相对路径,startsWith 匹配失效,
  // 这里用 MutationObserver 自动点掉遮罩按钮,让图片直接显示(对公告/评论/论坛帖统一生效)。
  'try{',
  'var revealed=new WeakSet();',
  'function revealBtn(b){try{if(!revealed.has(b)){revealed.add(b);b.click();}}catch(e){}}',
  'function scanReveal(root){try{',
  '  var bs=(root.querySelectorAll?root.querySelectorAll(".markdown__image button"):[]);',
  '  for(var i=0;i<bs.length;i++)revealBtn(bs[i]);',
  '}catch(e){}}',
  'scanReveal(document);',
  'new MutationObserver(function(muts){for(var i=0;i<muts.length;i++){',
  '  var add=muts[i].addedNodes;',
  '  for(var j=0;j<add.length;j++){var n=add[j];',
  '   if(n.nodeType!==1)continue;',
  '   if(n.matches&&n.matches(".markdown__image button"))revealBtn(n);',
  '   else if(n.querySelectorAll)scanReveal(n);',
  '  }}}).observe(document.documentElement,{childList:true,subtree:true});',
  '}catch(e){}',
  '})();',
].join('\n');

function injectPatch(html) {
  // 广告容器(Ad 组件渲染的 contentBlock)整块隐藏，避免留下空白占位
  const adblockCss = NO_AD_BLOCK ? '' :
    '<style data-iwara-proxy-adblock>.contentBlock{display:none!important}</style>';
  const tag = adblockCss +
    '<script data-iwara-proxy="1">' + PATCH_JS + '</script>';
  const m = /<head\b[^>]*>/i.exec(html);
  if (m) return html.slice(0, m.index + m[0].length) + tag + html.slice(m.index + m[0].length);
  return tag + html;
}

/* ---------------------------- 路由解析 ---------------------------- */

function parseTargetPath(raw) {
  if (raw === PREFIX || raw.startsWith(PREFIX)) {
    const rest = raw.slice(PREFIX.length);
    const qIdx = rest.indexOf('?');
    const pth = qIdx === -1 ? rest : rest.slice(0, qIdx);
    const search = qIdx === -1 ? '' : rest.slice(qIdx);
    const sIdx = pth.indexOf('/');
    const host = sIdx === -1 ? pth : pth.slice(0, sIdx);
    const path = sIdx === -1 ? '/' : pth.slice(sIdx);
    if (isAllowedHost(host)) return { host, path: path + search };
    return null;
  }
  return { host: SITE_HOST, path: raw };
}

/* --------------------------- 出口代理支持 --------------------------- */

// 通过 HTTP CONNECT 隧道访问上游（例如本机 clash / v2ray 的 http 端口）
class TunnelAgent extends https.Agent {
  constructor(proxyUrl, opts) {
    super(Object.assign({ keepAlive: true, maxSockets: 64 }, opts));
    this._px = proxyUrl;
  }
  createConnection(options, callback) {
    const port = options.port || 443;
    const headers = { Host: options.host + ':' + port };
    if (this._px.username || this._px.password) {
      headers['Proxy-Authorization'] = 'Basic ' + Buffer.from(
        decodeURIComponent(this._px.username + ':' + this._px.password)
      ).toString('base64');
    }
    const rq = http.request({
      host: this._px.hostname,
      port: Number(this._px.port || 80),
      method: 'CONNECT',
      path: options.host + ':' + port,
      headers,
      agent: false,
    });
    const onError = (e) => callback(e);
    rq.once('error', onError);
    rq.once('connect', (res, socket) => {
      rq.removeListener('error', onError);
      if (res.statusCode !== 200) {
        socket.destroy();
        return callback(new Error('UPSTREAM_PROXY CONNECT failed: HTTP ' + res.statusCode));
      }
      const sock = tls.connect({
        socket,
        servername: options.host,
        host: options.host,
        port,
      });
      callback(null, sock);
    });
    rq.end();
  }
}

const directAgent = new https.Agent({ keepAlive: true, maxSockets: 64 });
const tunnelAgent = UPSTREAM_PROXY ? new TunnelAgent(new URL(UPSTREAM_PROXY)) : null;
function agentFor() { return tunnelAgent || directAgent; }

/* ------------------------ 上游传输层（curl） ------------------------
 * Cloudflare 会按 TLS/JA3 指纹质询 Node 原生 https 客户端（cf-mitigated: challenge），
 * 而系统 curl（HTTP/2 + 常见 TLS 栈）可以直连，因此默认用 curl 子进程做上游传输，
 * 响应头解析后交给统一的 respond() 处理，流式转发不受影响。
 */

function curlUpstream(req, target, headers) {
  return new Promise((resolve, reject) => {
    const args = ['-sS', '--no-buffer', '--connect-timeout', '15',
      '--speed-limit', '10', '--speed-time', '45'].concat(curlExtraArgs);
    if (req.method === 'HEAD') args.push('-I');           // -I 让 curl 知道 HEAD 无响应体
    else args.push('-i', '-X', req.method);               // -i 把响应头一并输出到 stdout
    if (UPSTREAM_PROXY) args.push('-x', UPSTREAM_PROXY);  // 出口走 HTTP(S) 代理
    args.push('https://' + target.host + target.path);
    // UA 必须用 -A 传入：-H 'user-agent: ...' 会让 UA 排到默认 Accept 之后，
    // 改变请求头顺序，实测立刻触发 Cloudflare 质询
    if (headers['user-agent']) args.push('-A', String(headers['user-agent']));
    for (const k of Object.keys(headers)) {
      if (k === 'user-agent') continue;
      const v = headers[k];
      if (v === undefined || v === null) continue;
      args.push('-H', k + ': ' + String(Array.isArray(v) ? v.join(', ') : v));
    }
    const hasBody = req.method !== 'GET' && req.method !== 'HEAD';
    if (hasBody) args.push('--data-binary', '@-');        // 请求体从 stdin 流式读入

    let child;
    try {
      child = spawn('curl', args, {
        windowsHide: true,
        stdio: hasBody ? ['pipe', 'pipe', 'pipe'] : ['ignore', 'pipe', 'pipe'],
      });
    } catch (e) { return reject(e); }

    const { PassThrough } = require('stream');
    const upRes = new PassThrough();
    upRes.statusCode = 0;
    upRes.headers = {};
    upRes.complete = false;
    upRes.on('error', () => {}); // 防止在 attach 真正的错误处理前崩溃
    upRes.on('close', () => { try { child.kill(); } catch {} });

    let headerBuf = Buffer.alloc(0);
    let headersDone = false;
    let stderrTail = '';

    const fail = (msg) => {
      const e = new Error('curl: ' + msg);
      if (headersDone) upRes.destroy(e); else reject(e);
    };

    child.stdout.on('data', function onData(chunk) {
      if (headersDone) { upRes.write(chunk); return; }
      headerBuf = Buffer.concat([headerBuf, chunk]);
      for (;;) {
        const idx = headerBuf.indexOf('\r\n\r\n');
        if (idx === -1) {
          if (headerBuf.length > 512 * 1024) fail('响应头过大');
          return;
        }
        const block = headerBuf.slice(0, idx).toString('latin1');
        headerBuf = headerBuf.slice(idx + 4);
        const lines = block.split('\r\n');
        const m = /^HTTP\/[\d.]+\s+(\d{3})/i.exec(lines[0] || '');
        if (!m) return fail('无法解析状态行: ' + lines[0]);
        const status = Number(m[1]);
        if (status >= 100 && status < 200) continue; // 跳过 1xx 临时响应块
        const hh = {};
        const setCookies = [];
        for (let i = 1; i < lines.length; i++) {
          const c = lines[i].indexOf(':');
          if (c === -1) continue;
          const k = lines[i].slice(0, c).trim().toLowerCase();
          const v = lines[i].slice(c + 1).trim();
          if (k === 'set-cookie') setCookies.push(v);
          else hh[k] = hh[k] ? hh[k] + ', ' + v : v;
        }
        if (setCookies.length) hh['set-cookie'] = setCookies;
        upRes.statusCode = status;
        upRes.headers = hh;
        headersDone = true;
        if (headerBuf.length) upRes.write(headerBuf);
        headerBuf = null;
        resolve(upRes);
        return;
      }
    });
    child.stdout.on('end', () => { upRes.complete = true; upRes.end(); });
    child.stdout.on('error', () => {});
    child.stderr.on('data', (d) => { stderrTail = (stderrTail + d.toString()).slice(-400); });
    child.stderr.on('error', () => {});
    child.on('error', (e) => fail(e.message + '（找不到 curl？可设 TRANSPORT=node 改用直连）'));
    child.on('close', (code) => {
      if (!headersDone && code !== 0 && code !== null) {
        fail('exit=' + code + ' ' + stderrTail.trim());
      } else if (headersDone && code !== 0 && code !== null) {
        dbg('curl 中途退出 code=' + code, stderrTail.trim());
      }
    });

    if (hasBody) {
      child.stdin.on('error', () => {});
      req.on('aborted', () => { try { child.kill(); } catch {} });
      req.pipe(child.stdin);
    }
  });
}

// 启动时探测 curl 是否可用，并识别 schannel 构建（需要 --ssl-no-revoke）
function probeCurl() {
  return new Promise((resolve) => {
    let child;
    try { child = spawn('curl', ['--version'], { windowsHide: true }); }
    catch { return resolve(null); }
    let out = '';
    child.stdout.on('data', (d) => { out += d.toString(); });
    child.on('error', () => resolve(null));
    child.on('close', (code) => resolve(code === 0 ? out : null));
  });
}

/* ---------------------------- 请求头处理 ----------------------------
 * 实测（cf-mitigated: challenge）：
 *   - curl 指纹 + 浏览器式 accept / accept-encoding 头 => 被 Cloudflare 质询
 *   - 极简头(UA + accept 任意) + 功能性头(cookie/auth/range/x-version/origin/referer) => 全部 200
 * 因此对上游采用「白名单头」策略：只转发功能必需头，其余一律不转发。
 */

const REQ_KEEP = new Set([
  'user-agent', 'cookie', 'authorization', 'content-type', 'content-length',
  'range', 'if-none-match', 'if-modified-since', 'if-match', 'if-unmodified-since',
  'if-range', 'accept-language', 'x-version', 'x-captcha', 'x-requested-with',
  'x-umami-cache', 'x-site',
]);

function mapOurUrl(s) {
  // 把指向本代理的 referer 还原为上游真实 URL
  if (!s) return null;
  try {
    const u = new URL(s);
    let path = u.pathname + u.search;
    if (path.startsWith(PREFIX)) {
      const t = parseTargetPath(path);
      if (t) return 'https://' + t.host + t.path;
    }
    return 'https://' + SITE_HOST + path;
  } catch { return null; }
}

function upstreamHeaders(req, tgtHost) {
  const h = {};
  for (const k of Object.keys(req.headers)) {
    const lk = k.toLowerCase();
    if (REQ_KEEP.has(lk)) h[lk] = req.headers[k];
  }
  h.host = tgtHost;
  // 注意：不要显式设置 accept/accept-encoding —— curl 默认附加的 Accept 头能过 CF，
  // 显式 -H 'accept: ...' 会改变请求头顺序，实测立刻触发 Cloudflare 质询
  // 浏览器发来的 X-Site 是本代理的地址(如 127.0.0.1)，后端不认识，
  // 统一改写为真实站点主机名，AI 实例(iwara.ai)才能拿到 AI 内容
  if (h['x-site']) h['x-site'] = SITE_HOST;
  const ref = mapOurUrl(req.headers.referer);
  if (ref) h.referer = ref;
  if (req.headers.origin) h.origin = 'https://' + SITE_HOST;
  return h;
}

/* ---------------------------- 响应处理 ---------------------------- */

const REWRITE_CT = [
  'text/html', 'application/json', 'text/json', 'application/vnd.api+json',
  'javascript', 'ecmascript', 'text/css', 'text/x-component',
  'application/manifest', 'text/plain',
];

function isRewritableCt(ct) {
  ct = String(ct || '').toLowerCase().split(';')[0].trim();
  return REWRITE_CT.some((t) => ct.includes(t));
}

function accepts(ae, token) {
  return String(ae || '').toLowerCase().split(',')
    .some((s) => s.trim().split(';')[0] === token);
}

function decodeBuf(buf, enc) {
  if (!enc || enc === 'identity') return buf;
  if (enc.includes('gzip')) return zlib.gunzipSync(buf);
  if (enc.includes('deflate')) {
    try { return zlib.inflateSync(buf); } catch { return zlib.inflateRawSync(buf); }
  }
  if (enc.includes('br')) return zlib.brotliDecompressSync(buf);
  return buf;
}

function decodeStream(stream, enc) {
  if (enc.includes('gzip')) return stream.pipe(zlib.createGunzip());
  if (enc.includes('deflate')) return stream.pipe(zlib.createInflate());
  if (enc.includes('br')) return stream.pipe(zlib.createBrotliDecompress());
  return null;
}

function fixCookie(c) {
  // 去掉 Domain/Secure，让浏览器愿意在 http 的本站下保存并回发
  return c
    .replace(/;\s*domain=[^;]*/gi, '')
    .replace(/;\s*secure(?=$|;)/gi, '')
    .replace(/;\s*samesite=none/gi, '; samesite=lax');
}

const STRIP_RES_HEADERS = new Set([
  'connection', 'keep-alive', 'transfer-encoding',
  'content-security-policy', 'content-security-policy-report-only',
  'x-frame-options', 'cross-origin-opener-policy', 'cross-origin-embedder-policy',
  'cross-origin-resource-policy', 'alt-svc', 'alt-used', 'report-to', 'nel',
]);

function errorPage(err) {
  return '<!doctype html><meta charset="utf-8"><title>Iwara Proxy Error</title>'
    + '<body style="font-family:sans-serif;background:#111;color:#ddd;padding:2rem">'
    + '<h2>反代请求上游失败</h2><pre style="white-space:pre-wrap">' + String(err).replace(/[<>&]/g, ' ')
    + '</pre><p>若本机无法直连 iwara.tv，请设置环境变量 UPSTREAM_PROXY（HTTP 代理），例如：</p>'
    + '<pre>set UPSTREAM_PROXY=http://127.0.0.1:7890 &amp;&amp; node proxy.js</pre></body>';
}

function respond(req, res, upRes, target, t0) {
  const status = upRes.statusCode || 502;
  const h = upRes.headers;
  const ct = String(h['content-type'] || '').toLowerCase();
  const enc = String(h['content-encoding'] || '').trim().toLowerCase();
  const canRewrite = req.method !== 'OPTIONS' && isRewritableCt(ct);

  const out = {};
  for (const key of Object.keys(h)) {
    const lk = key.toLowerCase();
    if (STRIP_RES_HEADERS.has(lk)) continue;
    if (lk === 'content-encoding' || lk === 'content-length') continue; // 稍后按分支处理
    if (lk === 'set-cookie') continue;
    if (lk === 'location' || lk === 'link') continue;
    out[lk] = h[key];
  }
  if (h['set-cookie']) out['set-cookie'] = h['set-cookie'].map(fixCookie);
  if (h.location) out.location = rewriteText(String(h.location));
  if (h.link) out.link = [].concat(h.link).map((v) => rewriteText(String(v)));
  // /p/ 路由的 304 会让浏览器永远复用旧缓存体(可能含过期的签名 URL 或旧重写方案)，
  // 去掉验证器使其下次全量拉取
  if (status === 304 && req.url.startsWith(PREFIX)) {
    delete out.etag;
    delete out['last-modified'];
    out['cache-control'] = 'no-store';
  }
  // JSON/x-component 里的 URL 会被前端 new URL() 解析，必须重写为本站绝对地址；
  // 同时禁用缓存（fileUrl 带签名过期参数，且重写结果与请求 Host 相关）
  const jsonLike = /json|x-component|text\/plain/.test(ct);
  if (jsonLike) {
    out['cache-control'] = 'no-store';
    delete out.etag;
    delete out['last-modified'];
  }
  const doRewrite = makeRewriter(jsonLike ? requestOrigin(req) : null);

  // ---- 二进制流 / 其它类型：原样透传 ----
  if (!canRewrite) {
    const firstEnc = enc.split(',')[0].trim();
    const clientOk = !enc || enc === 'identity' || accepts(req.headers['accept-encoding'], firstEnc);
    let pipeFrom = upRes;
    if (enc && !clientOk) {
      const ds = decodeStream(upRes, enc);
      if (ds) pipeFrom = ds; // 客户端不接受该压缩时先解压
      else out['content-encoding'] = enc;
    } else if (enc) {
      out['content-encoding'] = enc;
    }
    if (out['content-encoding'] || !enc) {
      if (h['content-length'] != null) out['content-length'] = h['content-length'];
    }
    res.writeHead(status, out);
    pipeFrom.pipe(res);
    res.on('close', () => { if (!upRes.complete) upRes.destroy(); });
    log(req.method, req.url, '->', target.host + target.path, status, ms(t0));
    return;
  }

  // ---- 文本类：缓冲 -> 解压 -> 重写 -> (HTML 注入补丁) -> 回发 ----
  const chunks = [];
  upRes.on('data', (c) => chunks.push(c));
  upRes.on('error', () => {
    if (!res.headersSent) { res.writeHead(502, { 'content-type': 'text/html; charset=utf-8' }); res.end(errorPage('upstream read error')); }
    else res.destroy();
  });
  upRes.on('end', () => {
    let buf = Buffer.concat(chunks);
    try { buf = decodeBuf(buf, enc); }
    catch (e) { dbg('decompress failed:', e.message); }
    let text = buf.toString('utf8');
    try { text = doRewrite(text); }
    catch (e) { dbg('rewrite failed:', e.message); }
    if (ct.includes('text/html')) {
      try { text = injectPatch(text); } catch (e) { dbg('inject failed:', e.message); }
    }
    const body = Buffer.from(text, 'utf8');
    out['content-length'] = String(body.length);
    // HTML/JSON 内容随补丁版本变化，强制浏览器每次回源验证
    if (ct.includes('text/html')) out['cache-control'] = 'no-cache';
    res.writeHead(status, out);
    res.end(req.method === 'HEAD' ? undefined : body);
    res.on('close', () => { if (!upRes.complete) upRes.destroy(); });
    log(req.method, req.url, '->', target.host + target.path, status, body.length + 'B', ms(t0));
  });
}

function ms(t0) { return (Date.now() - t0) + 'ms'; }

/* ---------------------------- 主处理流程 ---------------------------- */

// node 原生 https 传输（备用；Cloudflare 会质询其 TLS 指纹）
function nodeUpstream(req, target, headers) {
  return new Promise((resolve, reject) => {
    const upReq = https.request({
      hostname: target.host,
      port: 443,
      path: target.path,
      method: req.method,
      headers,
      agent: agentFor(),
    }, resolve);
    upReq.setTimeout(60000, () => upReq.destroy(new Error('upstream timeout (60s)')));
    upReq.on('error', reject);
    req.pipe(upReq);
  });
}

function upstream(req, target, headers) {
  return TRANSPORT === 'curl' ? curlUpstream(req, target, headers) : nodeUpstream(req, target, headers);
}

async function handle(req, res) {
  const t0 = Date.now();
  const target = parseTargetPath(req.url);
  if (!target) {
    res.writeHead(403, { 'content-type': 'text/html; charset=utf-8' });
    res.end('<h1>403</h1><p>host 不在白名单内（可用 EXTRA_HOSTS / ALLOW_ANY_HOST 调整）</p>');
    return;
  }

  // 广告 / 追踪域名：直接 204 空响应（对 script/img/iframe 均无害）
  if (isBlockedHost(target.host)) {
    res.writeHead(204, { 'cache-control': 'no-store' });
    res.end();
    log('ADBLOCK', req.method, req.url);
    return;
  }

  let upRes;
  try {
    // Iwara 的 Service Worker(workbox 离线缓存)在本反代下会提供过期缓存页面、
    // 绕过运行时补丁，直接替换为空操作脚本
    if (req.method === 'GET' && (target.path === '/service-worker.js' || target.path.startsWith('/service-worker.js?'))) {
      const body = Buffer.from('// service worker disabled by iwara reverse proxy\nself.addEventListener("install",function(e){self.skipWaiting()});\n');
      res.writeHead(200, { 'content-type': 'application/javascript; charset=utf-8', 'cache-control': 'no-store', 'content-length': body.length });
      res.end(body);
      return;
    }
    upRes = await upstream(req, target, upstreamHeaders(req, target.host));
  } catch (e) {
    log('ERR', req.method, req.url, e.message);
    res.writeHead(502, { 'content-type': 'text/html; charset=utf-8' });
    res.end(errorPage(e.message));
    return;
  }

  upRes.on('error', (e) => {
    if (!res.headersSent) {
      res.writeHead(502, { 'content-type': 'text/html; charset=utf-8' });
      res.end(errorPage(e.message));
    } else res.destroy();
  });

  try { respond(req, res, upRes, target, t0); }
  catch (e) { log('ERR-respond', req.method, req.url, e.stack || e.message); if (!res.headersSent) { res.writeHead(500); res.end(); } }
}

const server = http.createServer((req, res) => {
  handle(req, res).catch((e) => {
    log('ERR500', req.method, req.url, e.stack || e.message);
    if (!res.headersSent) { res.writeHead(500, { 'content-type': 'text/html; charset=utf-8' }); res.end(errorPage(e.message)); }
    else res.destroy();
  });
});

server.on('clientError', (err, socket) => {
  if (socket.writable) socket.end('HTTP/1.1 400 Bad Request\r\n\r\n');
});

/* ------------------------------ 启动 ------------------------------ */

if (require.main === module) {
  server.on('error', (e) => {
    if (e.code === 'EADDRINUSE') {
      console.error('端口 ' + PORT + ' 已被占用，请换一个：PORT=9090 node proxy.js');
      process.exit(1);
    }
    throw e;
  });
  // 先探测 curl 可用性，再启动监听
  probeCurl().then((ver) => {
    if (TRANSPORT === 'curl') {
      if (!ver) {
        log('未检测到 curl，自动回退 TRANSPORT=node（可能被 Cloudflare 质询）');
        TRANSPORT = 'node';
      } else {
        if (/schannel/i.test(ver)) curlExtraArgs = ['--ssl-no-revoke'];
        log('curl 传输已启用: ' + String(ver).split('\n')[0].trim());
      }
    }
    server.listen(PORT, () => {
      log('Iwara reverse proxy 已启动: http://127.0.0.1:' + PORT + '  (同时监听局域网)');
      log('  站点域名 : ' + SITE_DOMAINS.join(' + ') + '  (X-Site -> ' + SITE_HOST + ')');
      log('  默认回源 : https://' + SITE_HOST);
      log('  出口代理 : ' + (UPSTREAM_PROXY || '(直连)'));
      log('  传输方式 : ' + TRANSPORT);
      log('  规则     : /            -> https://' + SITE_HOST + '/...');
      log('             /p/<host>/.. -> https://<host>/...');
      log('  广告拦截 : ' + (NO_AD_BLOCK ? '关闭' : '开启 (' + BLOCKED_HOSTS.size + ' 个域名)'));
      log('  白名单   : *.' + SITE_DOMAINS.join(', *.') + (EXTRA_HOSTS.length ? ' + ' + EXTRA_HOSTS.join(', ') : '') + (ALLOW_ANY_HOST ? ' + ANY(危险)' : ''));
    });
  });
}

module.exports = { rewriteText, parseTargetPath, isAllowedHost, isBlockedHost, injectPatch, PATCH_JS };
