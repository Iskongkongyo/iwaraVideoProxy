'use strict';
// 单元测试：node test.js
const assert = require('assert');
const { rewriteText, parseTargetPath, isAllowedHost, isBlockedHost, PATCH_JS } = require('./proxy');

let failed = 0;

const cases = [
  // [输入, 期望输出]
  ['https://api.iwara.tv/videos?limit=2', '/p/api.iwara.tv/videos?limit=2'],
  ['https://www.iwara.tv/video/abc123', '/video/abc123'],
  ['https://iwara.tv/forum', '/forum'],
  ['https://i.iwara.tv/image/original/x.jpg?w=800', '/p/i.iwara.tv/image/original/x.jpg?w=800'],
  ['https://xxx.iwara.tv/video?expires=1700000000&hash=abcdef', '/p/xxx.iwara.tv/video?expires=1700000000&hash=abcdef'],
  // JSON 转义形式
  ['"https:\\/\\/i.iwara.tv\\/image\\/x.jpg"', '"/p/i.iwara.tv\\/image\\/x.jpg"'],
  // unicode 转义形式（Next.js flight payload）
  ['https\\u003A\\u002F\\u002Fapi.iwara.tv\\u002Fuser', '/p/api.iwara.tv\\u002Fuser'],
  // 百分号编码形式
  ['redirect=https%3A%2F%2Fapi.iwara.tv%2Fvideos', 'redirect=%2Fp%2Fapi.iwara.tv%2Fvideos'],
  // 协议相对
  ['<img src="//i.iwara.tv/image/a.png">', '<img src="/p/i.iwara.tv/image/a.png">'],
  // 无关 URL 不受影响
  ['https://example.com/path', 'https://example.com/path'],
  ['https://api.iwara.tvX/x', 'https://api.iwara.tvX/x'],
  ['https://not-iwara-tv.example.com/', 'https://not-iwara-tv.example.com/'],
];

// 绝对模式（JSON/API 响应用）：重写为本站绝对 URL，new URL() 可解析
const absCases = [
  ['"fileUrl":"https://filesq.iwara.tv/file/abc?expires=1&hash=2"',
   '"fileUrl":"http://127.0.0.1:8888/p/filesq.iwara.tv/file/abc?expires=1&hash=2"'],
  ['"view":"https://acheron.iwara.tv/view?hash=x"',
   '"view":"http://127.0.0.1:8888/p/acheron.iwara.tv/view?hash=x"'],
  ['"link":"https://www.iwara.tv/video/x"', '"link":"http://127.0.0.1:8888/video/x"'],
];
for (const [input, expect] of absCases) {
  const got = rewriteText(input, 'http://127.0.0.1:8888');
  try { assert.strictEqual(got, expect); console.log('PASS  abs ' + input.slice(0, 50)); }
  catch { failed++; console.error('FAIL  abs ' + input + '\n  expect: ' + expect + '\n  got   : ' + got); }
}
// 绝对模式下 new URL() 必须能解析且 pathname/search 正确
{
  const out = rewriteText('https://filesq.iwara.tv/file/abc?expires=1&hash=2', 'http://127.0.0.1:8888');
  const u = new URL(out);
  assert.strictEqual(u.pathname, '/p/filesq.iwara.tv/file/abc');
  assert.strictEqual(u.searchParams.get('expires'), '1');
  console.log('PASS  abs URL parseable');
}
for (const [input, expect] of cases) {
  const got = rewriteText(input);
  try { assert.strictEqual(got, expect); console.log('PASS  ' + input.slice(0, 60)); }
  catch { failed++; console.error('FAIL  ' + input + '\n  expect: ' + expect + '\n  got   : ' + got); }
}

// 路由解析
const routes = [
  ['/', { host: 'www.iwara.tv', path: '/' }],
  ['/video/abc?x=1', { host: 'www.iwara.tv', path: '/video/abc?x=1' }],
  ['/p/api.iwara.tv/user/login', { host: 'api.iwara.tv', path: '/user/login' }],
  ['/p/xxx.iwara.tv/video?expires=1&hash=2', { host: 'xxx.iwara.tv', path: '/video?expires=1&hash=2' }],
  ['/p/i.iwara.tv/image/a.jpg', { host: 'i.iwara.tv', path: '/image/a.jpg' }],
];
for (const [input, expect] of routes) {
  const got = parseTargetPath(input);
  try { assert.deepStrictEqual(got, expect); console.log('PASS  route ' + input); }
  catch { failed++; console.error('FAIL  route ' + input + '\n  expect: ' + JSON.stringify(expect) + '\n  got   : ' + JSON.stringify(got)); }
}

// host 白名单
assert.strictEqual(isAllowedHost('api.iwara.tv'), true);
assert.strictEqual(isAllowedHost('xxx.iwara.tv'), true);
assert.strictEqual(isAllowedHost('evil.com'), false);
assert.strictEqual(isAllowedHost('xx.iwara.tv.evil.com'), false);
console.log('PASS  host allowlist');

// 广告域名：允许进入代理（以便拦截），且命中黑名单
assert.strictEqual(isAllowedHost('service.iwara.tv'), true);
assert.strictEqual(isAllowedHost('service.iwara.shop'), true);
assert.strictEqual(isBlockedHost('service.iwara.tv'), true);
assert.strictEqual(isBlockedHost('for-iwara-tools.tyamahori.com'), true);
assert.strictEqual(isBlockedHost('www.googletagmanager.com'), true);
assert.strictEqual(isBlockedHost('api.iwara.tv'), false);
assert.strictEqual(isBlockedHost('www.iwara.tv'), false);
// 广告域名 URL 会被静态重写进代理（以便拦截）
assert.strictEqual(
  rewriteText('<script src="https://www.googletagmanager.com/gtag/js"></script>'),
  '<script src="/p/www.googletagmanager.com/gtag/js"></script>'
);
assert.ok(PATCH_JS.includes('googletagmanager'), '运行时补丁需包含广告域');
console.log('PASS  ad blocklist');

// 注入的浏览器补丁脚本必须是合法 JS（不执行）
new Function(PATCH_JS);
console.log('PASS  patch script syntax');

// AI 站实例模式：SITE_DOMAIN=iwara.ai 时需同时覆盖 .ai 与 .tv 两个域名家族
const { execFileSync } = require('child_process');
const aiScript = `
process.env.SITE_DOMAIN = 'iwara.ai';
const p = require('./proxy');
const assert = require('assert');
assert.strictEqual(p.isAllowedHost('www.iwara.ai'), true);
assert.strictEqual(p.isAllowedHost('api.iwara.tv'), true);
assert.strictEqual(p.isAllowedHost('i.iwara.tv'), true);
assert.strictEqual(p.isBlockedHost('service.iwara.tv'), true);
assert.strictEqual(p.rewriteText('https://www.iwara.ai/video/x'), '/video/x');
assert.strictEqual(p.rewriteText('https://api.iwara.tv/videos'), '/p/api.iwara.tv/videos');
assert.strictEqual(p.rewriteText('"//files.iwara.tv/x"'), '"/p/files.iwara.tv/x"');
new Function(p.PATCH_JS);
console.log('AI-MODE-OK');
`;
try {
  const out = execFileSync(process.execPath, ['-e', aiScript], { cwd: __dirname, encoding: 'utf8' });
  if (!out.includes('AI-MODE-OK')) throw new Error(out);
  console.log('PASS  AI 站实例模式 (SITE_DOMAIN=iwara.ai)');
} catch (e) { failed++; console.error('FAIL  AI mode: ' + String(e.message).slice(0, 300)); }

if (failed) { console.error(failed + ' test(s) failed'); process.exit(1); }
console.log('全部通过 ✔');
