# Iwara Worker Dual — Cloudflare Workers 双站反代

在原有 Iwara Worker 版本上增加 `iwara.ai` 支持，同时保留 `iwara.tv`。支持两种部署方式：

1. **单 Worker + 两个代理域名**：通过请求进入 Worker 时的 hostname 选择主站或 AI 站；
2. **分别部署两个 Worker**：使用 `SITE_DOMAIN` 分别选择 `iwara.tv` 或 `iwara.ai`。

主站与 AI 站共用的 `api.iwara.tv`、`i.iwara.tv`、视频文件域名等仍通过 `/p/<host>/...` 代理。

## 方式 A：一个 Worker 同时反代两个站点（推荐）

将两个代理域名/路由都指向同一个 Worker，例如：

- `tv-proxy.example.com` → `www.iwara.tv`
- `ai-proxy.example.com` → `www.iwara.ai`

在 Worker → **Settings → Variables and Secrets → Variables** 添加：

| 变量 | 值 |
| --- | --- |
| `SITE_HOST_MAP` | `tv-proxy.example.com=www.iwara.tv,ai-proxy.example.com=www.iwara.ai` |

把示例中的代理域名替换为你自己的两个域名。Worker 会按请求进入时的 hostname 选择上游站点，不需要在 URL 路径里增加 `/ai` 前缀。

如果请求来自未配置映射的域名，则回退到 `UPSTREAM_SITE` / `SITE_DOMAIN` 默认值。

## 方式 B：分别部署两个 Worker

主站 Worker 使用默认配置即可：

| 变量 | 值 |
| --- | --- |
| `SITE_DOMAIN` | `iwara.tv`（可省略，默认值） |

AI 站 Worker 添加：

| 变量 | 值 |
| --- | --- |
| `SITE_DOMAIN` | `iwara.ai` |

也可以通过 `UPSTREAM_SITE=www.iwara.ai` 选择 AI 站。AI 模式会自动同时放行 `*.iwara.ai` 和 `*.iwara.tv`，其中 API、图片和视频后端仍然可以使用 `.iwara.tv` 域名。

> 单个代理 hostname 的根路径一次只能对应一个默认上游站点。若希望同一个 Worker 同时提供两个不同首页，需要使用两个代理 hostname 并配置 `SITE_HOST_MAP`，或分别部署两个 Worker。

## 双站兼容处理

- URL 重写同时识别 `iwara.tv` 与 `iwara.ai` 域名家族。
- 两个站点的根域名和 `www` 域名都会映射到当前代理域名。
- `api.iwara.tv`、`i.iwara.tv`、`files*.iwara.tv` 等共享后端仍通过 `/p/<host>/...` 转发。
- 转发浏览器的 `X-Site` 请求头时，会将它改写为实际站点上游主机名（例如 `www.iwara.ai`），避免上游把 AI 站请求识别成主站请求。
- `Origin`、`Referer`、重定向地址和 JSON 中的视频/图片绝对 URL 会根据当前入口站点正确处理。
- 新增 `service.iwara.ai` 广告域拦截。
- 视频、图片二进制流仍直接流式透传，继续保留 Range / 206。

## 部署

### Cloudflare Dashboard

1. 进入 **Workers & Pages**，创建 Worker。
2. 将 `worker.js` 全部复制到在线编辑器并 Deploy。
3. 按上面的方式配置环境变量。
4. 在 Worker 的 **Settings → Domains & Routes** 中配置代理域名或路由。
5. 若使用方式 A，确保两个代理 hostname 都指向同一个 Worker。

### Wrangler

```bash
npm test
npx wrangler deploy
```

修改 `wrangler.toml` 中的名称，并按需配置 `[vars]`。也可以在 Dashboard 中设置变量。

## 环境变量

| 变量 | 默认值 | 说明 |
| --- | --- | --- |
| `SITE_HOST_MAP` | 空 | 代理入口 hostname 到上游站点的映射，格式 `proxy-tv.example.com=www.iwara.tv,proxy-ai.example.com=www.iwara.ai` |
| `SITE_DOMAIN` | `iwara.tv` | 默认站点域名；可设为 `iwara.ai` |
| `UPSTREAM_SITE` | `www.<SITE_DOMAIN>` | 默认回源主机；`SITE_HOST_MAP` 匹配成功时优先使用映射值 |
| `EXTRA_HOSTS` | 空 | 额外允许反代的主机，逗号分隔 |
| `BLOCK_HOSTS` | 空 | 追加拦截的主机，逗号分隔 |
| `NO_AD_BLOCK` | `0` | 设为 `1` 关闭广告域名拦截和广告容器隐藏 |
| `ALLOW_ANY_HOST` | `0` | 设为 `1` 允许任意目标主机；不建议开启，会变成开放代理 |
| `DEBUG` | `0` | 设为 `1` 输出调试日志 |

## 关于 Cloudflare 人机验证

此版本仍使用 Workers 原生 `fetch()` 访问上游，不使用 curl 或自定义 TLS 指纹。双站改造不会改变上游连接方式；如果当前单站 Worker 已经能正常访问，新增 AI 站也应先按相同方式实测，但不能保证 Iwara 永远不会返回 Cloudflare Challenge。

## 测试

```bash
npm test
```

测试覆盖默认主站兼容、AI 站回源、双 hostname 映射、`X-Site` / `Origin` / `Referer` 改写、URL 重写、广告域拦截、运行时补丁语法，以及模拟 Worker 请求的集成测试。

仅供个人学习研究使用，请遵守目标网站的服务条款，不要用于公开镜像或未经授权的分发。
