import assert from 'node:assert/strict';
import {
  getConfig,
  isAllowedHost,
  isBlockedHost,
  parseTargetPath,
  rewriteText,
  buildClientPatch,
  upstreamHeaders,
  handleRequest,
} from './worker.js';

let passed = 0;
function test(name, fn) {
  fn();
  passed++;
  console.log('PASS', name);
}
async function testAsync(name, fn) {
  await fn();
  passed++;
  console.log('PASS', name);
}

// 默认主站行为保持不变。
const tv = getConfig();
test('default site remains iwara.tv', () => {
  assert.equal(tv.siteHost, 'www.iwara.tv');
  assert.deepEqual(tv.siteDomains, ['iwara.tv']);
  assert.deepEqual(parseTargetPath('/video/abc?x=1', tv), {
    host: 'www.iwara.tv', path: '/video/abc?x=1',
  });
  assert.equal(rewriteText('https://api.iwara.tv/videos'), '/p/api.iwara.tv/videos');
  assert.equal(rewriteText('https://www.iwara.tv/video/x'), '/video/x');
});

// AI 单站实例：默认回源 iwara.ai，同时放行 iwara.tv 的 API/图片/视频后端。
const ai = getConfig({ SITE_DOMAIN: 'iwara.ai' });
test('AI site config and routing', () => {
  assert.equal(ai.siteHost, 'www.iwara.ai');
  assert.deepEqual(ai.siteDomains, ['iwara.tv', 'iwara.ai']);
  assert.deepEqual(parseTargetPath('/watch/abc', ai), {
    host: 'www.iwara.ai', path: '/watch/abc',
  });
  assert.deepEqual(parseTargetPath('/p/api.iwara.tv/videos', ai), {
    host: 'api.iwara.tv', path: '/videos',
  });
  assert.equal(isAllowedHost('www.iwara.ai', ai), true);
  assert.equal(isAllowedHost('api.iwara.tv', ai), true);
  assert.equal(isAllowedHost('files.iwara.ai', ai), true);
  assert.equal(isAllowedHost('evil.example', ai), false);
});

test('AI and shared backend URL rewriting', () => {
  assert.equal(rewriteText('https://www.iwara.ai/video/x', null, ai), '/video/x');
  assert.equal(rewriteText('https://iwara.ai/forum', null, ai), '/forum');
  assert.equal(rewriteText('https://api.iwara.tv/videos', null, ai), '/p/api.iwara.tv/videos');
  assert.equal(rewriteText('https://i.iwara.tv/image/a.jpg', null, ai), '/p/i.iwara.tv/image/a.jpg');
  assert.equal(rewriteText('https://api.iwara.ai/user', null, ai), '/p/api.iwara.ai/user');
  assert.equal(
    rewriteText('"fileUrl":"https://files.iwara.tv/a.mp4"', 'https://ai-proxy.example.com', ai),
    '"fileUrl":"https://ai-proxy.example.com/p/files.iwara.tv/a.mp4"',
  );
  assert.equal(
    rewriteText('https\\u003A\\u002F\\u002Fapi.iwara.tv\\u002Fuser', null, ai),
    '/p/api.iwara.tv\\u002Fuser',
  );
});

test('AI ad host is intercepted and rewritable', () => {
  assert.equal(isAllowedHost('service.iwara.ai', ai), true);
  assert.equal(isBlockedHost('service.iwara.ai', ai), true);
  assert.equal(
    rewriteText('https://service.iwara.ai/ad.js', null, ai),
    '/p/service.iwara.ai/ad.js',
  );
});

// 单 Worker 双入口：两个代理域名映射到不同上游站点。
const dualEnv = {
  SITE_HOST_MAP: 'tv-proxy.example.com=www.iwara.tv,ai-proxy.example.com=www.iwara.ai',
};
const tvMapped = getConfig(dualEnv, 'https://tv-proxy.example.com/');
const aiMapped = getConfig(dualEnv, 'https://ai-proxy.example.com/');
test('one Worker can select both sites by incoming hostname', () => {
  assert.equal(tvMapped.siteHost, 'www.iwara.tv');
  assert.equal(aiMapped.siteHost, 'www.iwara.ai');
  assert.deepEqual(tvMapped.siteDomains, ['iwara.tv', 'iwara.ai']);
  assert.deepEqual(aiMapped.siteDomains, ['iwara.tv', 'iwara.ai']);
  assert.equal(rewriteText('https://www.iwara.ai/video/x', null, aiMapped), '/video/x');
  assert.equal(rewriteText('https://www.iwara.tv/video/x', null, tvMapped), '/video/x');
});

test('X-Site, Origin and Referer are rewritten for AI upstream', () => {
  const req = new Request('https://ai-proxy.example.com/p/api.iwara.tv/videos', {
    headers: {
      'x-site': 'ai-proxy.example.com',
      origin: 'https://ai-proxy.example.com',
      referer: 'https://ai-proxy.example.com/video/abc',
    },
  });
  const headers = upstreamHeaders(req, aiMapped);
  assert.equal(headers.get('x-site'), 'www.iwara.ai');
  assert.equal(headers.get('origin'), 'https://www.iwara.ai');
  assert.equal(headers.get('referer'), 'https://www.iwara.ai/video/abc');
});

test('runtime patch compiles and includes both site families', () => {
  const patch = buildClientPatch(ai);
  assert.doesNotThrow(() => new Function(patch));
  assert.match(patch, /iwara\\\\\.ai/);
  assert.match(patch, /www\.iwara\.ai/);
  assert.match(patch, /DOMALT/);
  const domainAlt = 'iwara\\.tv|iwara\\.ai';
  const basePattern = new RegExp('^\\/p\\/((?:[a-z0-9-]+\\.)*(?:' + domainAlt + '))(?:\\/.*)?$', 'i');
  assert.equal(basePattern.exec('/p/files.iwara.ai/video.mp4')[1], 'files.iwara.ai');
});

await testAsync('request host map selects upstream and rewrites JSON response', async () => {
  const originalFetch = globalThis.fetch;
  let capturedUrl;
  let capturedHeaders;
  globalThis.fetch = async (url, init) => {
    capturedUrl = String(url);
    capturedHeaders = new Headers(init.headers);
    return new Response('{"fileUrl":"https://files.iwara.tv/video.mp4"}', {
      status: 200,
      headers: { 'content-type': 'application/json; charset=utf-8' },
    });
  };
  try {
    const request = new Request('https://ai-proxy.example.com/p/api.iwara.tv/video/123', {
      headers: { 'x-site': 'ai-proxy.example.com' },
    });
    const response = await handleRequest(request, dualEnv);
    const body = await response.text();
    assert.equal(capturedUrl, 'https://api.iwara.tv/video/123');
    assert.equal(capturedHeaders.get('x-site'), 'www.iwara.ai');
    assert.match(body, /https:\/\/ai-proxy\.example\.com\/p\/files\.iwara\.tv\/video\.mp4/);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

console.log(`全部通过：${passed} 项测试 ✔`);
