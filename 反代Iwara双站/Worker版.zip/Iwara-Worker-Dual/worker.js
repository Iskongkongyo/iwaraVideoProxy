/**
 * Iwara Reverse Proxy — Cloudflare Workers 原生版本
 *
 * Iwara Worker Dual：同时兼容 iwara.tv / iwara.ai。
 * 路由：
 *   /                  -> 当前入口映射的站点（默认 https://www.iwara.tv/...）
 *   /p/<host>/<path>   -> https://<host>/<path>
 *
 * SITE_HOST_MAP 可让同一个 Worker 根据不同代理 hostname 选择不同站点。
 * 说明：Worker 使用平台 fetch() 访问上游，不支持 curl 子进程、任意 TCP
 * CONNECT 隧道或自定义 TLS 指纹。因此无法保证绕过上游 Cloudflare Challenge。
 */

const PREFIX = '/p/';

const AD_HOSTS = [
  'service.iwara.tv',
  'service.iwara.ai',
  'service.iwara.shop',
  'for-iwara-tools.tyamahori.com',
  'www.googletagmanager.com',
  'www.google-analytics.com',
  'analytics.google.com',
  'stats.g.doubleclick.net',
];

const RE_AD_HOSTS = [
  'service\\.iwara\\.ai',
  'service\\.iwara\\.shop',
  'for-iwara-tools\\.tyamahori\\.com',
  'www\\.googletagmanager\\.com',
  'www\\.google-analytics\\.com',
  'analytics\\.google\\.com',
  'stats\\.g\\.doubleclick\\.net',
];

const REQ_KEEP = new Set([
  'user-agent', 'cookie', 'authorization', 'content-type',
  'range', 'if-none-match', 'if-modified-since', 'if-match',
  'if-unmodified-since', 'if-range', 'accept-language',
  'x-version', 'x-captcha', 'x-requested-with', 'x-umami-cache', 'x-site',
]);

const STRIP_RES_HEADERS = new Set([
  'connection', 'keep-alive', 'transfer-encoding',
  'content-security-policy', 'content-security-policy-report-only',
  'x-frame-options', 'cross-origin-opener-policy',
  'cross-origin-embedder-policy', 'cross-origin-resource-policy',
  'alt-svc', 'alt-used', 'report-to', 'nel',
]);

const REWRITE_CT = [
  'text/html', 'application/json', 'text/json',
  'application/vnd.api+json', 'javascript', 'ecmascript',
  'text/css', 'text/x-component', 'application/manifest', 'text/plain',
];

function csv(value) {
  return String(value || '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
}

function inferSiteDomain(value) {
  const host = cleanHost(value);
  if (host === 'iwara.ai' || host.endsWith('.iwara.ai')) return 'iwara.ai';
  return 'iwara.tv';
}

function normalizeSiteHost(value, fallbackDomain = 'iwara.tv') {
  const host = cleanHost(value || ('www.' + fallbackDomain));
  if (host === 'iwara.tv' || host === 'www.iwara.tv') return 'www.iwara.tv';
  if (host === 'iwara.ai' || host === 'www.iwara.ai') return 'www.iwara.ai';
  return /^[a-z0-9.-]+$/.test(host) ? host : ('www.' + fallbackDomain);
}

function parseSiteHostMap(value) {
  const map = Object.create(null);
  for (const item of String(value || '').split(',').map((s) => s.trim()).filter(Boolean)) {
    const split = item.indexOf('=');
    if (split <= 0) continue;
    const proxyHost = cleanHost(item.slice(0, split));
    const upstreamHost = normalizeSiteHost(item.slice(split + 1));
    if (!/^[a-z0-9.-]+$/.test(proxyHost)) continue;
    // 站点映射只允许两个官方站点，避免配置项意外变成任意回源入口。
    if (upstreamHost === 'www.iwara.tv' || upstreamHost === 'www.iwara.ai') {
      map[proxyHost] = upstreamHost;
    }
  }
  return map;
}

function getConfig(env = {}, requestUrl = null) {
  const rawUpstream = String(env.UPSTREAM_SITE || '').trim().toLowerCase();
  const rawDomain = String(env.SITE_DOMAIN || '').trim().toLowerCase();
  const primaryDomain = rawDomain === 'iwara.ai' || rawDomain === 'iwara.tv'
    ? rawDomain
    : inferSiteDomain(rawUpstream || 'www.iwara.tv');
  const defaultSiteHost = normalizeSiteHost(rawUpstream || ('www.' + primaryDomain), primaryDomain);
  const siteHostMap = parseSiteHostMap(env.SITE_HOST_MAP);
  let requestHost = '';
  if (requestUrl) {
    try { requestHost = new URL(requestUrl).hostname.toLowerCase(); } catch {}
  }
  const siteHost = siteHostMap[requestHost] || defaultSiteHost;
  const siteDomains = new Set(['iwara.tv']);
  if (primaryDomain === 'iwara.ai' || defaultSiteHost === 'www.iwara.ai' ||
      Object.values(siteHostMap).includes('www.iwara.ai')) {
    siteDomains.add('iwara.ai');
  }
  const extraHosts = csv(env.EXTRA_HOSTS).filter((h) => /^[a-z0-9.-]+$/.test(h));
  const userBlockHosts = csv(env.BLOCK_HOSTS).filter((h) => /^[a-z0-9.-]+$/.test(h));
  return {
    siteHost,
    siteDomains: [...siteDomains],
    siteHostMap,
    extraHosts,
    userBlockHosts,
    allowAnyHost: String(env.ALLOW_ANY_HOST || '0') === '1',
    noAdBlock: String(env.NO_AD_BLOCK || '0') === '1',
    debug: String(env.DEBUG || '0') === '1',
  };
}

function cleanHost(host) {
  return String(host || '').toLowerCase().replace(/\.+$/, '').replace(/:\d+$/, '');
}

function isBlockedHost(host, config = getConfig()) {
  if (config.noAdBlock) return false;
  const h = cleanHost(host);
  const blocked = new Set(AD_HOSTS.concat(config.userBlockHosts).map(cleanHost));
  return blocked.has(h);
}

function isAllowedHost(host, config = getConfig()) {
  const raw = String(host || '').toLowerCase().replace(/\.+$/, '');
  if (!/^[a-z0-9.-]+$/.test(raw)) return false;
  const h = cleanHost(raw);
  if (!h) return false;

  // 广告域名必须能进入代理层，才能由代理返回 204；关闭广告拦截时也允许访问。
  if (AD_HOSTS.some((d) => h === d || h.endsWith('.' + d))) return true;
  if (config.userBlockHosts.some((d) => h === d || h.endsWith('.' + d))) return true;
  if (config.allowAnyHost) return true;
  if (config.siteDomains.some((d) => h === d || h.endsWith('.' + d))) return true;
  return config.extraHosts.some((d) => h === d || h.endsWith('.' + d));
}

function parseTargetPath(raw, config = getConfig()) {
  if (raw === PREFIX || raw.startsWith(PREFIX)) {
    const rest = raw.slice(PREFIX.length);
    const qIdx = rest.indexOf('?');
    const pathname = qIdx === -1 ? rest : rest.slice(0, qIdx);
    const search = qIdx === -1 ? '' : rest.slice(qIdx);
    const slashIdx = pathname.indexOf('/');
    const host = (slashIdx === -1 ? pathname : pathname.slice(0, slashIdx)).toLowerCase();
    const path = slashIdx === -1 ? '/' : pathname.slice(slashIdx);
    if (isAllowedHost(host, config)) return { host, path: path + search };
    return null;
  }
  return { host: config.siteHost, path: raw || '/' };
}

function escapeRe(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function makeRewriter(origin, config = getConfig()) {
  const domainAlt = config.siteDomains.map(escapeRe).join('|');
  const baseLabel = '(?:[a-zA-Z0-9-]+\\.)*(?:' + domainAlt + ')';
  const hostsSrc = '(?:' + [baseLabel].concat(
    RE_AD_HOSTS,
    config.extraHosts.map(escapeRe),
    config.userBlockHosts.map(escapeRe),
  ).join('|') + ')';
  const bareHosts = new Set();
  for (const domain of config.siteDomains) {
    bareHosts.add(domain);
    bareHosts.add('www.' + domain);
  }

  const reAbs = new RegExp(
    'https(?::|\\\\u003[aA]|\\\\x3[aA])(?:\\/\\/|\\\\\\/\\\\\\/|\\\\u002[fF]\\\\u002[fF])'
      + '(' + hostsSrc + ')(?::443)?(?![a-zA-Z0-9-])',
    'gi',
  );
  const rePct = new RegExp('https%3[aA]%2[fF]%2[fF](' + hostsSrc + ')(?::443)?', 'gi');
  const reRel = new RegExp('(?<![\\w.:-])\\/\\/(' + hostsSrc + ')(?![a-zA-Z0-9-])', 'gi');

  const abs = (host) => {
    const h = host.toLowerCase().replace(/:443$/, '');
    if (bareHosts.has(h)) return origin || '';
    return origin ? origin + PREFIX + h : PREFIX + h;
  };

  return function rewriteText(text) {
    let result = String(text);
    result = result.replace(reAbs, (_m, host) => abs(host));
    result = result.replace(rePct, (_m, host) => {
      const replacement = abs(host);
      return replacement ? encodeURIComponent(replacement) : '';
    });
    result = result.replace(reRel, (_m, host) => abs(host));
    return result;
  };
}

function rewriteText(text, origin = null, config = getConfig()) {
  return makeRewriter(origin, config)(text);
}

function buildClientPatch(config = getConfig()) {
  const domainAlt = config.siteDomains.map(escapeRe).join('|');
  const extraClientHosts = RE_AD_HOSTS.concat(
    config.extraHosts.map(escapeRe),
    config.userBlockHosts.map(escapeRe),
  );
  const clientHostSrc = '((?:[a-z0-9-]+\\.)*(?:' + domainAlt +
    (extraClientHosts.length ? '|' + extraClientHosts.join('|') : '') + '))';
  const bareHosts = {};
  for (const domain of config.siteDomains) {
    bareHosts[domain] = 1;
    bareHosts['www.' + domain] = 1;
  }

  return [
    '(function(){',
    '"use strict";',
    'window.__iwaraProxyErrors=[];',
    'window.addEventListener("error",function(e){window.__iwaraProxyErrors.push(String(e.message||e.error)+" @ "+String(e.filename||"").slice(-70)+":"+e.lineno);});',
    'window.addEventListener("unhandledrejection",function(e){window.__iwaraProxyErrors.push("REJ: "+String(e.reason).slice(0,150)+" STACK: "+String(e.reason&&e.reason.stack||"").slice(0,400));});',
    'var HS=' + JSON.stringify(clientHostSrc) + ';',
    'var BARE=' + JSON.stringify(bareHosts) + ';',
    'var DOMALT=' + JSON.stringify(domainAlt) + ';',
    'var FAKE="http://iwara-proxy.invalid";',
    'var RX=new RegExp("^https?://"+HS+"(?=[/?#:]|$)","i");',
    'var RX3=new RegExp("^//"+HS+"(?=[/?#:]|$)","i");',
    'var RX2=/^http:\\/\\/iwara-proxy\\.invalid(?=[\\/?#:]|$)/;',
    'function fix(u){',
    ' try{',
    '  if(u&&typeof u==="object"&&typeof u.href==="string")u=u.href;',
    '  if(typeof u!=="string"||!u)return u;',
    '  if(u.charAt(0)==="/"&&u.charAt(1)==="/"){',
    '   var m3=RX3.exec(u);',
    '   if(m3){var h3=m3[1].toLowerCase(),r3=u.slice(m3[0].length);',
    '    if(BARE[h3])return r3||"/";',
    '    return "/p/"+h3+r3;}',
    '   return u;}',
    '  if(u.charAt(0)==="/"&&u.charAt(1)!=="/")return u;',
    '  if(RX2.test(u))return u.slice(FAKE.length)||"/";',
    '  var m=RX.exec(u);',
    '  if(!m)return u;',
    '  var h=m[1].toLowerCase(),rest=u.slice(m[0].length);',
    '  if(BARE[h])return rest||"/";',
    '  return "/p/"+h+rest;',
    ' }catch(e){return u;}',
    '}',
    'try{var of=window.fetch;if(of)window.fetch=function(input,init){try{',
    '  if(typeof input==="string")input=fix(input);',
    '  else if(input&&typeof input.href==="string")input=fix(input.href);',
    '}catch(e){}return of.call(this,input,init);};}catch(e){}',
    'try{var oo=XMLHttpRequest.prototype.open;XMLHttpRequest.prototype.open=function(){',
    '  var a=[].slice.call(arguments);if(typeof a[1]==="string")a[1]=fix(a[1]);',
    '  return oo.apply(this,a);};}catch(e){}',
    'try{var os=Element.prototype.setAttribute;Element.prototype.setAttribute=function(n,v){',
    '  if(typeof v==="string"&&/^(src|href|poster|action|data)$/i.test(n))v=fix(v);',
    '  return os.call(this,n,v);};}catch(e){}',
    '[["HTMLImageElement","src"],["HTMLSourceElement","src"],["HTMLIFrameElement","src"],',
    ' ["HTMLScriptElement","src"],["HTMLTrackElement","src"],["HTMLMediaElement","src"],',
    ' ["HTMLMediaElement","poster"],["HTMLAnchorElement","href"],["HTMLLinkElement","href"],',
    ' ["HTMLFormElement","action"]].forEach(function(p){try{',
    '  var C=window[p[0]];if(!C)return;',
    '  var d=Object.getOwnPropertyDescriptor(C.prototype,p[1]);',
    '  if(d&&d.set&&d.configurable)Object.defineProperty(C.prototype,p[1],{',
    '    configurable:true,enumerable:d.enumerable,get:d.get,',
    '    set:function(v){return d.set.call(this,fix(v));}});',
    ' }catch(e){}});',
    'try{window.URL=(function(PU){return class extends PU{constructor(u,b){try{',
    '  if(typeof b==="string"&&b.charAt(0)==="/"){',
    '    var m=new RegExp("^\\\\/p\\\\/((?:[a-z0-9-]+\\\\.)*(?:"+DOMALT+"))(?:\\\\/.*)?$","i").exec(b);',
    '    if(m){if(typeof u==="string"&&u.charAt(0)==="/")u=FAKE+u;b=FAKE+"/p/"+m[1]+"/";}',
    '  }',
    '}catch(e){}super(u,b);}};})(URL);}catch(e){}',
    'try{',
    'var revealed=new WeakSet();',
    'function revealBtn(b){try{if(!revealed.has(b)){revealed.add(b);b.click();}}catch(e){}}',
    'function scanReveal(root){try{',
    '  var bs=(root.querySelectorAll?root.querySelectorAll(".markdown__image button"):[]);',
    '  for(var i=0;i<bs.length;i++)revealBtn(bs[i]);',
    '}catch(e){}}',
    'scanReveal(document);',
    'new MutationObserver(function(muts){for(var i=0;i<muts.length;i++){',
    '  var add=muts[i].addedNodes;',
    '  for(var j=0;j<add.length;j++){var n=add[j];',
    '   if(n.nodeType!==1)continue;',
    '   if(n.matches&&n.matches(".markdown__image button"))revealBtn(n);',
    '   else if(n.querySelectorAll)scanReveal(n);',
    '  }}}).observe(document.documentElement,{childList:true,subtree:true});',
    '}catch(e){}',
    '})();',
  ].join('\n');
}

function injectPatch(html, config = getConfig()) {
  const adblockCss = config.noAdBlock ? '' :
    '<style data-iwara-proxy-adblock>.contentBlock{display:none!important}</style>';
  const tag = adblockCss + '<script data-iwara-proxy="1">' + buildClientPatch(config) + '</script>';
  const match = /<head\b[^>]*>/i.exec(html);
  if (match) return html.slice(0, match.index + match[0].length) + tag + html.slice(match.index + match[0].length);
  return tag + html;
}

function mapOurUrl(value, config) {
  if (!value) return null;
  try {
    const url = new URL(value);
    const path = url.pathname + url.search;
    if (url.pathname.startsWith(PREFIX)) {
      const target = parseTargetPath(path, config);
      if (target) return 'https://' + target.host + target.path;
    }
    return 'https://' + config.siteHost + path;
  } catch {
    return null;
  }
}

function upstreamHeaders(request, config) {
  const headers = new Headers();
  for (const name of REQ_KEEP) {
    const value = request.headers.get(name);
    if (value !== null) headers.set(name, value);
  }

  const referer = mapOurUrl(request.headers.get('referer'), config);
  if (referer) headers.set('referer', referer);
  if (request.headers.has('origin')) headers.set('origin', 'https://' + config.siteHost);
  // Iwara AI 与主站共用 api.iwara.tv；X-Site 决定返回哪个站点的内容。
  // 浏览器发来的可能是代理域名，必须替换为实际上游站点主机名。
  if (request.headers.has('x-site')) headers.set('x-site', config.siteHost);

  // 不转发浏览器的 Accept / Accept-Encoding / Host / Content-Length。
  // Worker fetch 会自行管理连接、压缩和 Host；上游头部保持最小化。
  headers.delete('content-length');
  headers.delete('host');
  headers.delete('accept');
  headers.delete('accept-encoding');
  return headers;
}

function isRewritableCt(contentType) {
  const ct = String(contentType || '').toLowerCase().split(';')[0].trim();
  return REWRITE_CT.some((token) => ct.includes(token));
}

function fixCookie(cookie) {
  // 删除上游 Domain，令浏览器将 Cookie 保存到反代域名；HTTPS 下保留 Secure。
  return String(cookie).replace(/;\s*domain=[^;]*/gi, '');
}

function splitSetCookie(headers) {
  if (typeof headers.getSetCookie === 'function') return headers.getSetCookie();
  if (typeof headers.getAll === 'function') {
    try { return headers.getAll('set-cookie'); } catch {}
  }
  const raw = headers.get('set-cookie');
  if (!raw) return [];
  // 兼容不提供 getSetCookie() 的运行时；Expires 日期中的逗号不会匹配此规则。
  return raw.split(/,(?=\s*[^;,=\s]+=[^;,]*)/g);
}

function appendCookies(sourceHeaders, targetHeaders) {
  for (const cookie of splitSetCookie(sourceHeaders)) {
    targetHeaders.append('set-cookie', fixCookie(cookie));
  }
}

function normalResponseHeaders(upstream, request, target, config, contentType) {
  const headers = new Headers();
  for (const [name, value] of upstream.headers) {
    const key = name.toLowerCase();
    if (STRIP_RES_HEADERS.has(key) || key === 'set-cookie' || key === 'location' || key === 'link') continue;
    headers.set(name, value);
  }
  appendCookies(upstream.headers, headers);

  const location = upstream.headers.get('location');
  if (location) headers.set('location', rewriteText(location, null, config));
  const link = upstream.headers.get('link');
  if (link) headers.set('link', rewriteText(link, null, config));

  if (upstream.status === 304 && new URL(request.url).pathname.startsWith(PREFIX)) {
    headers.delete('etag');
    headers.delete('last-modified');
    headers.set('cache-control', 'no-store');
  }

  const jsonLike = /json|x-component|text\/plain/i.test(contentType);
  if (jsonLike) {
    headers.set('cache-control', 'no-store');
    headers.delete('etag');
    headers.delete('last-modified');
  }
  return { headers, jsonLike };
}

function challengeResponse(upstream) {
  // 不改写 CF challenge 页面及其 CSP/脚本资源；仅移除 Domain 以便浏览器保存 Cookie。
  const headers = new Headers(upstream.headers);
  headers.delete('set-cookie');
  appendCookies(upstream.headers, headers);
  const status = upstream.status;
  const body = (status === 204 || status === 304) ? null : upstream.body;
  return new Response(body, { status, headers });
}

function isChallengeResponse(response, contentType) {
  if (String(response.headers.get('cf-mitigated') || '').toLowerCase() === 'challenge') return true;
  // 即使上游未返回 cf-mitigated，也不要把常见的 HTML 403/503 验证页注入脚本。
  return (response.status === 403 || response.status === 503) && /text\/html/i.test(contentType);
}

function htmlEscape(value) {
  return String(value).replace(/[&<>"']/g, (ch) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[ch]);
}

function errorPage(error) {
  return '<!doctype html><meta charset="utf-8"><title>Iwara Worker Proxy Error</title>' +
    '<body style="font-family:sans-serif;background:#111;color:#ddd;padding:2rem">' +
    '<h2>Iwara Worker 访问上游失败</h2><pre style="white-space:pre-wrap">' + htmlEscape(error) +
    '</pre><p>请检查 Worker 出站请求及上游可访问性。Worker fetch 无法配置本地 HTTP CONNECT 代理或 curl TLS 指纹。</p></body>';
}

function log(config, ...args) {
  if (config.debug) console.log('[iwara-worker]', ...args);
}

async function handleRequest(request, env = {}) {
  const incomingUrl = new URL(request.url);
  const config = getConfig(env, request.url);
  const target = parseTargetPath(incomingUrl.pathname + incomingUrl.search, config);

  if (!target) {
    return new Response('<h1>403</h1><p>Host 不在白名单内。可通过 EXTRA_HOSTS 添加额外域名。</p>', {
      status: 403,
      headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' },
    });
  }

  if (isBlockedHost(target.host, config)) {
    return new Response(null, { status: 204, headers: { 'cache-control': 'no-store' } });
  }

  const targetPath = target.path.split('?')[0];
  if (request.method === 'GET' && targetPath === '/service-worker.js') {
    const body = '// service worker disabled by iwara reverse proxy\n' +
      'self.addEventListener("install",function(e){self.skipWaiting()});\n';
    return new Response(body, {
      status: 200,
      headers: {
        'content-type': 'application/javascript; charset=utf-8',
        'cache-control': 'no-store',
      },
    });
  }

  const upstreamUrl = 'https://' + target.host + target.path;
  const init = {
    method: request.method,
    headers: upstreamHeaders(request, config),
    redirect: 'manual',
    cache: 'no-store',
    signal: request.signal,
  };
  if (request.method !== 'GET' && request.method !== 'HEAD') init.body = request.body;

  let upstream;
  try {
    upstream = await fetch(upstreamUrl, init);
  } catch (error) {
    log(config, 'UPSTREAM ERROR', request.method, incomingUrl.pathname, String(error));
    return new Response(errorPage(error && error.message ? error.message : error), {
      status: 502,
      headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' },
    });
  }

  const contentType = String(upstream.headers.get('content-type') || '').toLowerCase();
  if (isChallengeResponse(upstream, contentType)) {
    log(config, 'CF CHALLENGE', upstream.status, target.host + target.path);
    return challengeResponse(upstream);
  }

  const status = upstream.status;
  const canHaveBody = request.method !== 'HEAD' && status !== 204 && status !== 304;
  const canRewrite = canHaveBody && request.method !== 'OPTIONS' && isRewritableCt(contentType);

  if (!canRewrite) {
    const { headers } = normalResponseHeaders(upstream, request, target, config, contentType);
    const body = canHaveBody ? upstream.body : null;
    log(config, request.method, incomingUrl.pathname, '->', target.host + target.path, status);
    return new Response(body, { status, headers });
  }

  const { headers, jsonLike } = normalResponseHeaders(upstream, request, target, config, contentType);
  headers.delete('content-length');
  headers.delete('content-encoding');

  let text;
  try {
    text = await upstream.text();
  } catch (error) {
    log(config, 'BODY READ ERROR', String(error));
    return new Response(errorPage('读取上游响应失败：' + (error && error.message ? error.message : error)), {
      status: 502,
      headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' },
    });
  }

  try {
    const origin = jsonLike ? incomingUrl.origin : null;
    text = makeRewriter(origin, config)(text);
  } catch (error) {
    log(config, 'REWRITE ERROR', String(error));
  }

  if (contentType.includes('text/html')) {
    try {
      text = injectPatch(text, config);
    } catch (error) {
      log(config, 'HTML INJECT ERROR', String(error));
    }
    headers.set('cache-control', 'no-cache');
  }

  log(config, request.method, incomingUrl.pathname, '->', target.host + target.path, status, text.length + ' chars');
  return new Response(text, { status, headers });
}

export {
  getConfig,
  parseSiteHostMap,
  isAllowedHost,
  isBlockedHost,
  parseTargetPath,
  rewriteText,
  makeRewriter,
  buildClientPatch,
  injectPatch,
  upstreamHeaders,
  handleRequest,
};

export default {
  fetch: handleRequest,
};
